Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============== RESTART: E:\CTI110 WebDesign\P3HW2_PlaciousItara.py =============
Enter employee's name: Itara Placious
Enter number of hours worked: 45
Enter employee's pay rate: 17.5
------------------------------
Employee name: Itara Placious

Hours Worked    Pay Rate    OverTime    OverTime Pay    RegHour Pay    Gross Pay
--------------------------------------------------------------------------------
 45.0           17.5       5.0        131.25         $700.00       $831.25      
>>> 
============== RESTART: E:\CTI110 WebDesign\P3HW2_PlaciousItara.py =============
Enter employee's name: Itara Placious
Enter number of hours worked: 45
Enter employee's pay rate: 17.5
------------------------------
Employee name: Itara Placious

Hours Worked   Pay Rate   OverTime   OverTime Pay   RegHour Pay   Gross Pay
--------------------------------------------------------------------------------
 45.0           17.5       5.0        131.25         $700.00       $831.25      
>>> 
============== RESTART: E:\CTI110 WebDesign\P3HW2_PlaciousItara.py =============
Enter employee's name: Itara Placious
Enter number of hours worked: 45
Enter employee's pay rate: 17.5
------------------------------
Employee name: Itara Placious

Hours Worked   Pay Rate   OverTime   OverTime Pay   RegHour Pay   Gross Pay
--------------------------------------------------------------------------------
45.0           17.5       5.0        131.25         $700.00       $831.25      
